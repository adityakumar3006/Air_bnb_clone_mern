//--------------------------------------------------------------------------------Tab2-----------------------------------------------------------------
	window.onload = function () { 
		openTab('tab1'); 
	  };
	var aras=window.parent.parent.aras; 
	var myInnovator = aras.newIOMInnovator(); 
	  
	  function openTab(tabId) { 
		var tabs = document.querySelectorAll('.tab'); 
		var tabContents = document.querySelectorAll('.tab-content');
		const element=document.querySelectorAll('.dropdowntab2')[0];
		if(tabId=='tab1'){
			
				if(element){
				element.style.display="block";
				}
			}
			if(tabId=='tab2'){
			
				if(element){
				element.style.display="none";
				}
			}
			if(tabId=='tab3'){
			
				if(element){
				element.style.display="none";
				}
			}
				var content = document.getElementById(tabId); 
				var itemType=thisItem.getType();
				var classification = itemType;
				if(document.getElementById(classification)==null || document.getElementById(classification).length<=1 && tabContents.length==0){
			
			if(tabId=='tab2'){
			debugger;
						for (var i = 0; i < 1; i++) { 
							tabs[i].classList.remove('active-tab'); 
							tabs[i].setAttribute('aria-selected', 'false');
							var ul_classification = document.getElementById('classification');
							var li = document.createElement('li');
							li.setAttribute('id',classification);
							li.setAttribute('name',classification);
							li.setAttribute('class','expandable-list-item xbtn-1');
							li.setAttribute('onClick',"toggleList('item1')");
							li.innerHTML = classification;
							ul_classification.appendChild(li); 
			}	
					var query = "<AML><Item type='sg_approved_questionandanswer' action='get'><classification>"+itemType+"</classification></Item></AML>"; 
					var result = myInnovator.applyAML(query); 
					var sg_approved_questionandanswer_list = []; 
					for (var i = 0; i < result.getItemCount(); i++) { 
					var item = result.getItemByIndex(i); 
					var questionValue = item.getProperty("sg_question"); 
					sg_approved_questionandanswer_list.push(questionValue);   } 
					var dropdown = document.getElementById("dropdownContent_tab2"); 
					var div = document.createElement("div"); 
					div.classList.add('scrollable-container')
	if (sg_approved_questionandanswer_list.length > 0) {
		div.appendChild(document.createElement("br"));
	}

for (var i = 0; i < sg_approved_questionandanswer_list.length; i++) {
    var mainDiv = document.createElement("div");

    var iconDiv = document.createElement("div");
    var icon = document.createElement("i");
    icon.classList.add("fas", "fa-angle-right");
    icon.style.paddingRight = "3px";
    iconDiv.appendChild(icon);

    var textDiv = document.createElement("div");
    var a = document.createElement("a");
    a.style.cursor = "pointer"; 
	a.style.cursor = "15px";
	//margin-right: 15px;
    a.addEventListener("click", function () {
        
        var clickedLink = this;
        var ItemQue = aras.IomInnovator.newItem("sg_approved_questionandanswer", "get");
        ItemQue.setProperty("sg_question", clickedLink.textContent);
        ItemQue = ItemQue.apply();
        var IdQue = ItemQue.getID();
        top.aras.uiShowItem('sg_approved_questionandanswer', IdQue, 'tab view', false);
    });
    a.textContent = sg_approved_questionandanswer_list[i];
    textDiv.appendChild(a);

    mainDiv.appendChild(iconDiv);
    mainDiv.appendChild(textDiv);
    mainDiv.style.display = "flex";

    div.appendChild(mainDiv);
    div.appendChild(document.createElement("br"));
}
div.style.margin = "-5px 7px";
div.style.border = "0px solid white";
content.appendChild(div);

		} 

		}
		var style = document.createElement('style');
		style.textContent = `
			.scrollable-container { max-height: 600px; overflow: auto; border: 1px solid #ccc; margin: 10px; margin-right: 2px; margin-top: 8px }
			.fa-angle-right:before { padding: 6px; }
		`;
		document.head.appendChild(style);


			for (var i = 0; i < tabContents.length; i++) {
				tabContents[i].style.display = 'none';
			}

			for (var i = 0; i < tabs.length; i++) {
				var currentTab = tabs[i];
				var currentTabContent = document.getElementById(currentTab.getAttribute('data-tab'));

				if (currentTab.getAttribute('data-tab') !== tabId) {
				   
					currentTab.classList.remove('active-tab');
					currentTab.setAttribute('aria-selected', 'false');
					currentTabContent.style.display = 'none';
				} else {
				   
					currentTab.classList.add('active-tab');
					currentTab.setAttribute('aria-selected', 'true');
					currentTabContent.style.display = 'block';
				}
			}
			}
// ----------------------------------------------General Information Dropdown-------------------------------------------------------------------------------------------------- 
function toggleDropdown(dropdownId, arrowId) {
    debugger;

    var dropdown = document.getElementById(dropdownId);
    var arrow = document.getElementById(arrowId);

    // Toggle the rotation of the icon
    dropdown.classList.toggle('hidden');
    if (dropdown.classList.contains('hidden')) {
        arrow.classList.remove('fa-angle-right');
        arrow.classList.add('fa-angle-down');
		dropdown.style.display='grid';
    } else {
        arrow.classList.remove('fa-angle-down');
        arrow.classList.add('fa-angle-right'); 
		dropdown.style.display='none';
    }
	
}

document.addEventListener("DOMContentLoaded", function() {
    var dropdown = document.getElementById('partDropdown'); 
    if (dropdown) {
        dropdown.classList.add('hidden');	
        console.log('Dropdown is hidden by default.');
    } else {
        console.log('Dropdown element not found.');
    }
});

document.addEventListener("DOMContentLoaded", function() {
    var dropdown = document.getElementById('partDropdown2'); 
    if (dropdown) {
        dropdown.classList.add('hidden');	
        console.log('Dropdown is hidden by default.');
    } else {
        console.log('Dropdown element not found.');
    }
});


//-------------------------------------------Function For Tab3 submitFeedback------------------------------------------------------------------ 
function submitFeedback() { 
    try { 
	debugger;
	
        var description = document.getElementById("desp1").value; 
        var title = document.getElementById("title1").value; 
        var itemType = 'sg_feedback'; 
        var inn = parent.thisItem.getInnovator(); 
        var userID = inn.getUserID(); 
        var guid = aras.generateNewGUID(); 
        var Todaysdate = new Date(); 
        var Currentdate = 
            Todaysdate.getFullYear() + "-" + 
            ((Todaysdate.getMonth() + 1) < 10 ? "0" + (Todaysdate.getMonth() + 1) : Todaysdate.getMonth() + 1) + "-" + 
            (Todaysdate.getDate() < 10 ? "0" + Todaysdate.getDate() : Todaysdate.getDate()); 
        console.log(Currentdate); 

        var itemProps = { 
            'sg_guid_code': 'GUID', 
            'sg_description': 'value1', 
            'sg_title': 'value2',          
        };        

        var newItem = inn.newItem(itemType, 'add'); 
        newItem.setProperty("sg_guid_code", guid); 
        newItem.setProperty("sg_description", description); 
        newItem.setProperty("sg_title", title); 
        newItem.setProperty("sg_date", Currentdate); 
        newItem.setProperty("sg_login_user", userID); 
        newItem = newItem.apply(); 

        // Check if the item was created successfully 
        if (newItem.isError()) { 
            aras.AlertError("Error creating Item!!");
        } else { 
            // Hide the form container
            document.getElementById("feedbackFormContainer").style.display = "none";

            // Show Thank You Message
            document.getElementById("thankYouMessage").style.display = "block";
            aras.AlertSuccess("Item created successfully!!");
        } 
    } catch (ex) { 
        alert("Exception: " + ex); 
    } 
}
